import {
    CognitoIdentityProviderClient,
    InitiateAuthCommand,
    AuthFlowType,
} from "@aws-sdk/client-cognito-identity-provider";
import type { APIGatewayProxyEvent, APIGatewayProxyResult } from "aws-lambda";

const client = new CognitoIdentityProviderClient({});
const CLIENT_ID = process.env.COGNITO_CLIENT_ID as string;

const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
};

type LoginBody = {
    email: string;
    password: string;
}

export const handler = async (
    event: APIGatewayProxyEvent
): Promise<APIGatewayProxyResult> => {
    try {
        if (!event.body) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({ message: "Falta el Body!" })
            }
        }
        const { email, password }: LoginBody = JSON.parse(event.body);
        const command = new InitiateAuthCommand({
            AuthFlow: AuthFlowType.USER_PASSWORD_AUTH,
            ClientId: CLIENT_ID,
            AuthParameters: {
                USERNAME: email,
                PASSWORD: password
            }
        })
        const response = await client.send(command);
        const { AccessToken, IdToken, RefreshToken, ExpiresIn } =
            response.AuthenticationResult as any;

        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
                accessToken: AccessToken,
                idToken: IdToken,
                refreshToken: RefreshToken,
                expiresIn: ExpiresIn,
            }),
        };

    } catch (error: any) {
        console.error("Error en login:", error);

        // Errores típicos de Cognito: NotAuthorizedException, UserNotFoundException, etc.
        if (
            error.name === "NotAuthorizedException" ||
            error.name === "UserNotFoundException"
        ) {
            return {
                statusCode: 401,
                headers,
                body: JSON.stringify({ message: "Credenciales inválidas" }),
            };
        }

        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ message: "Error interno", error: error.message }),
        };
    }
}