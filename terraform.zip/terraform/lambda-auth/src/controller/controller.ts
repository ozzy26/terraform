const type = {
    "1": 1
}