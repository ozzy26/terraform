resource "aws_lambda_layer_version" "this" {
  filename            = var.filename
  layer_name          = var.layer_name
  compatible_runtimes = var.compatible_runtimes
  source_code_hash    = filebase64sha256(var.filename)
}
