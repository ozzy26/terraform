variable "filename" {
  description = "Ruta al zip de la layer"
  type        = string
}

variable "layer_name" {
  description = "Nombre de la layer"
  type        = string
}

variable "compatible_runtimes" {
  description = "Runtimes compatibles"
  type        = list(string)
}
