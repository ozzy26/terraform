output "invoke_url" {
  value = aws_api_gateway_stage.dev.invoke_url
}

output "login_url" {
  value = "${aws_api_gateway_stage.dev.invoke_url}/auth"
}

output "products_url" {
  value = "${aws_api_gateway_stage.dev.invoke_url}/products"
}

output "execution_arn" {
  value = aws_api_gateway_rest_api.api.execution_arn
}
