variable "api_name" {
  description = "Nombre del API Gateway"
  type        = string
  default     = "terraform-api-gateway"
}

variable "stage_name" {
  description = "Nombre del stage"
  type        = string
  default     = "dev"
}

variable "cognito_user_pool_arn" {
  description = "ARN del Cognito User Pool usado por el authorizer"
  type        = string
}

variable "products_lambda_function_name" {
  description = "Nombre de la función Lambda de /products"
  type        = string
}

variable "products_lambda_invoke_arn" {
  description = "invoke_arn de la función Lambda de /products"
  type        = string
}

variable "auth_lambda_function_name" {
  description = "Nombre de la función Lambda de /auth"
  type        = string
}

variable "auth_lambda_invoke_arn" {
  description = "invoke_arn de la función Lambda de /auth"
  type        = string
}
