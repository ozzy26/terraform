variable "user_pool_name" {
  description = "Nombre del Cognito User Pool"
  type        = string
  default     = "terraform-user-pool"
}

variable "client_name" {
  description = "Nombre del User Pool Client"
  type        = string
  default     = "terraform-cognito-user-pool-client"
}

variable "password_min_length" {
  description = "Longitud mínima de password"
  type        = number
  default     = 8
}
