variable "function_name" {
  description = "Nombre de la función Lambda"
  type        = string
}

variable "handler" {
  description = "Handler de la función"
  type        = string
  default     = "dist/index.handler"
}

variable "runtime" {
  description = "Runtime de la función"
  type        = string
}

variable "filename" {
  description = "Ruta al zip del código"
  type        = string
}

variable "role_arn" {
  description = "ARN del rol IAM de ejecución"
  type        = string
}

variable "layers" {
  description = "Lista de ARNs de layers a adjuntar"
  type        = list(string)
  default     = []
}

variable "environment_variables" {
  description = "Variables de entorno de la función"
  type        = map(string)
  default     = {}
}
