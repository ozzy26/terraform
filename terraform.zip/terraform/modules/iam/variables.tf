variable "role_name" {
  description = "Nombre del rol IAM de ejecución de las lambdas"
  type        = string
  default     = "terraform-lambda-role"
}

variable "s3_policy_name" {
  description = "Nombre de la policy de acceso a S3"
  type        = string
  default     = "terraform-lambda-s3"
}

variable "s3_bucket_arn" {
  description = "ARN del bucket S3 al que la lambda necesita acceso (con /* al final)"
  type        = string
  default     = "arn:aws:s3:::mi-bucket-archivos/*"
}
